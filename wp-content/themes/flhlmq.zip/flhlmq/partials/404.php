<body>
  <div class="erreur">
    <img class="erreur__404" src="<?php bloginfo('template_url'); ?>/assets/erreur/404.png" alt="erreur 404">
    <img class="erreur__img" src="<?php bloginfo('template_url'); ?>/assets/erreur/maison.jpg" alt="erreur 404">
  </div>
</body>