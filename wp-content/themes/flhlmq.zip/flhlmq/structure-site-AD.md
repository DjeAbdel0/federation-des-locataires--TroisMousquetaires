# Acceuil
## TYPE DE CONTENU 
-Page

## MODÈLE (TEMPLATE)
- home.php
## COMPOSANTE DE LA PAGE
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
- hero.php
### CHAMPS PERSONNALISÉS (CUSTOM FIELDS) DE CETTE COMPOSANTE
-hero_title: Text
-hero_image: Gallery
## AUTRES CHAMPS PERSONNALISÉS (CUSTOM FIELDS) SANS LIEN AVEC UNE COMPOSANTE
-actualite_title: Text
### testi:Group
-testi_title: Text
-testi_icon: Image
-testi_name: Text
-testi_description: TextArea
-testi_btn : Text
### services:Group
-services_title: Text
-services_icon: Image
-services_name: Text
### donation:Group
-donation_title: Text
-donation_description: TextArea
-donation_btn : Text
-donation_image: Image
            _______________________ Fini __________________________
# À propos
## TYPE DE CONTENU (POST TYPE)
-Page
## MODÈLE (TEMPLATE)
-about.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
-paragraphe.php
### CHAMPS PERSONNALISÉS (CUSTOM FIELDS) DE CETTE COMPOSANTE
-paragraphe_title: Text
-paragraphe_image: Image
-paragraphe_descrition: TextArea
## AUTRES CHAMPS PERSONNALISÉS (CUSTOM FIELDS) SANS LIEN AVEC UNE COMPOSANTE

            _______________________ Fini __________________________
# Contact
## TYPE DE CONTENU (POST TYPE)
-Page
## MODÈLE (TEMPLATE)
-formulaire.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
-join.php
### CHAMPS PERSONNALISÉS (CUSTOM FIELDS) DE CETTE COMPOSANTE
-name_contact: Text
-email_contact: Email
-message_contact: TextArea
## AUTRES CHAMPS PERSONNALISÉS (CUSTOM FIELDS) SANS LIEN AVEC UNE COMPOSANTE
### join:Group
-join_title: Text
-join_description: TextArea
-join_phone: Number
-join_fax: Number
-join_email: Email
-join_map: GoodleMap

            _______________________ Fini __________________________
# Erreur_404
## TYPE DE CONTENU (POST TYPE)
-Page
## MODÈLE (TEMPLATE)
-erreur_404.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
### CHAMPS PERSONNALISÉS (CUSTOM FIELDS) DE CETTE COMPOSANTE
## AUTRES CHAMPS PERSONNALISÉS (CUSTOM FIELDS) SANS LIEN AVEC UNE COMPOSANTE

            _______________________ Fini __________________________
# Nouvelle
## TYPE DE CONTENU (POST TYPE)
-news
## MODÈLE (TEMPLATE)
-news.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
### CHAMPS PERSONNALISÉS (CUSTOM FIELDS) DE CETTE COMPOSANTE
-news_description :  TextArea
-news_image: Image
-news_title: Text
## AUTRES CHAMPS PERSONNALISÉS (CUSTOM FIELDS) SANS LIEN AVEC UNE COMPOSANTE
### newsList:Group
-newsList_title: Text
#### newsCard:Group
-news_card_title: Text
-news_card_image: Image
-news_card_descrition: Text
-news_card_date: Text
-news_card_btn : Text
            _______________________ Fini __________________________
# Liste_Nouvelles
## MODÈLE (TEMPLATE)
-home.php
## COMPOSANTE DE LA PAGE
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
-hero.php
### CHAMPS PERSONNALISÉS (CUSTOM FIELDS) DE CETTE COMPOSANTE
-hero_title: Text
-hero_image: Image
-hero_description: TextArea
-hero_btn: Text
-hero_date: Text
## AUTRES CHAMPS PERSONNALISÉS (CUSTOM FIELDS) SANS LIEN AVEC UNE COMPOSANTE
#### newsCard:Group
-news_card_title: Text
-news_card_image: Image
-news_card_date: Text
-news_card_tag : Text

            _______________________ Fini __________________________
# Service
## TYPE DE CONTENU (POST TYPE)
-Service
## MODÈLE (TEMPLATE)
-service.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
### CHAMPS PERSONNALISÉS (CUSTOM FIELDS) DE CETTE COMPOSANTE
-service_description: TextArea
-service_image: Image
-service_title: Text
## AUTRES CHAMPS PERSONNALISÉS (CUSTOM FIELDS) SANS LIEN AVEC UNE COMPOSANTE
-autres_services_title: Text
### autresServices: Group
-autres_services_image: Image
-autres_services_name: Text
            _______________________ Fini __________________________
# Liste_Services
## TYPE DE CONTENU (POST TYPE)
-Page
## MODÈLE (TEMPLATE)
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
-hero.php
### CHAMPS PERSONNALISÉS (CUSTOM FIELDS) DE CETTE COMPOSANTE
-hero_title: Text
-hero_image: Image
## AUTRES CHAMPS PERSONNALISÉS (CUSTOM FIELDS) SANS LIEN AVEC UNE COMPOSANTE
### servicesList: Group
-services_list_description: TextArea
-services_list_image: Image
-services_list_title: Text
-services_list_btn: Text
            _______________________ Fini __________________________
# Team
## TYPE DE CONTENU (POST TYPE)
-Page
## MODÈLE (TEMPLATE)
-home.php
## COMPOSANTE DE LA PAGES
### NOM DU PARTIAL DU THÈME WP POUR CETTE COMPOSTANTE
-hero.php
### CHAMPS PERSONNALISÉS (CUSTOM FIELDS) DE CETTE COMPOSANTE
-hero_title: Text
-hero_image: gallery
## AUTRES CHAMPS PERSONNALISÉS (CUSTOM FIELDS) SANS LIEN AVEC UNE COMPOSANTE
-team_title: Text
### member: Group
-member_name: Text
-member_image: Image


 
