<?php
/**
 * Modèle de la page 404
 * Template Name: erreur
 * Template Post Type: page
 */

get_header(); // Affiche header.php

get_template_part( 'partials/404' ); // Affiche partials/404.php
		
get_footer(); // Affiche footer.php 
?>